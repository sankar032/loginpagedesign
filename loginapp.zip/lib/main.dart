import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

void main() {
  runApp(
    MaterialApp(
      title: "Login Ui App",
      debugShowCheckedModeBanner: false,
      home: HomePage(),
    ),
  );
}

class HomePage extends StatefulWidget {
  @override
  _HomePageState createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  bool signin = true;
  @override
  Widget build(BuildContext context) {
    return AnnotatedRegion<SystemUiOverlayStyle>(
      value: SystemUiOverlayStyle(
        statusBarColor: Color(0xff306060),
      ),
      child: SafeArea(
        child: Scaffold(
          backgroundColor: Color(0xff306060),
          body: Column(
            children: <Widget>[
              Container(
                padding: EdgeInsets.all(20),
                height: MediaQuery.of(context).size.height * 0.25,
                width: double.infinity,
                child: Column(
                  children: <Widget>[
                    Row(
                      children: <Widget>[
                        Icon(
                          Icons.widgets,
                          color: Colors.white,
                          size: 30,
                        ),
                        Spacer(),
                        GestureDetector(
                          onTap: () {
                            setState(() {
                              signin = true;
                            });
                          },
                          child: Container(
                            padding: EdgeInsets.only(
                              top: 8,
                              bottom: 8,
                              left: 15,
                              right: 15,
                            ),
                            decoration: BoxDecoration(
                              color:
                                  signin ? Colors.black26 : Colors.transparent,
                              borderRadius: BorderRadius.circular(30),
                            ),
                            child: Text(
                              "Sign In",
                              style: TextStyle(
                                color: signin ? Colors.white : Colors.white70,
                                fontSize: signin ? 18 : 17,
                                fontFamily: 'Loto',
                              ),
                            ),
                          ),
                        ),
                        SizedBox(
                          width: 10,
                        ),
                        GestureDetector(
                          onTap: () {
                            setState(() {
                              signin = false;
                            });
                          },
                          child: Container(
                            padding: EdgeInsets.only(
                              top: 8,
                              bottom: 8,
                              left: 15,
                              right: 15,
                            ),
                            decoration: BoxDecoration(
                              color: signin == false
                                  ? Colors.black26
                                  : Colors.transparent,
                              borderRadius: BorderRadius.circular(30),
                            ),
                            child: Text(
                              "Sign Up",
                              style: TextStyle(
                                color: signin == false
                                    ? Colors.white
                                    : Colors.white70,
                                fontSize: signin == false ? 18 : 17,
                                fontFamily: 'Loto',
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),
                    Expanded(
                      child: Container(
                        width: double.infinity,
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: <Widget>[
                            Spacer(),
                            signin
                                ? Text(
                                    "Welcome back,",
                                    style: TextStyle(
                                      color: Colors.white,
                                      fontSize: 35,
                                      fontWeight: FontWeight.bold,
                                      fontFamily: "Roboto",
                                    ),
                                  )
                                : Text(
                                    "Hey, get on board",
                                    style: TextStyle(
                                      color: Colors.white,
                                      fontSize: 35,
                                      fontWeight: FontWeight.bold,
                                      fontFamily: "Roboto",
                                    ),
                                  ),
                            SizedBox(
                              height: 20,
                            ),
                            signin
                                ? Text(
                                    "Sign in to continue",
                                    style: TextStyle(
                                      color: Colors.white,
                                      fontSize: 20,
                                      fontFamily: "Roboto",
                                    ),
                                  )
                                : Text(
                                    "Sign up to continue",
                                    style: TextStyle(
                                      color: Colors.white,
                                      fontSize: 20,
                                      fontFamily: "Roboto",
                                    ),
                                  ),
                          ],
                        ),
                      ),
                    ),
                  ],
                ),
              ),
              Expanded(
                child: Container(
                  padding: EdgeInsets.only(
                    top: 30,
                    left: 20,
                    right: 20,
                  ),
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.only(
                      topLeft: Radius.circular(30),
                      topRight: Radius.circular(30),
                    ),
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: <Widget>[
                      signin
                          ? SizedBox()
                          : Text(
                              "Username",
                              style: TextStyle(
                                color: Colors.black,
                                fontSize: 22,
                                fontFamily: "Roboto",
                                fontWeight: FontWeight.w500,
                              ),
                            ),
                      signin
                          ? SizedBox()
                          : TextFormField(
                              keyboardType: TextInputType.emailAddress,
                              initialValue: "Sankar",
                            ),
                      signin
                          ? SizedBox()
                          : SizedBox(
                              height: 30,
                            ),
                      Text(
                        "Email Address",
                        style: TextStyle(
                          color: Colors.black,
                          fontSize: 22,
                          fontFamily: "Roboto",
                          fontWeight: FontWeight.w500,
                        ),
                      ),
                      TextFormField(
                        keyboardType: TextInputType.emailAddress,
                        initialValue: "msankar032@gmail.com",
                        decoration: InputDecoration(
                          suffix: Icon(
                            Icons.check,
                            color: Colors.green,
                            size: 20,
                          ),
                        ),
                      ),
                      SizedBox(
                        height: 30,
                      ),
                      Text(
                        "Password",
                        style: TextStyle(
                          color: Colors.black,
                          fontSize: 22,
                          fontFamily: "Roboto",
                          fontWeight: FontWeight.w500,
                        ),
                      ),
                      TextFormField(
                        keyboardType: TextInputType.emailAddress,
                        obscureText: true,
                        initialValue: "Password",
                      ),
                      signin
                          ? Container(
                              padding: EdgeInsets.only(
                                top: 10,
                                bottom: 10,
                              ),
                              child: Align(
                                alignment: Alignment.centerRight,
                                child: Text(
                                  "Forget Password?",
                                  style: TextStyle(
                                    color: Colors.orange,
                                    fontSize: 20,
                                    fontFamily: "Roboto",
                                  ),
                                ),
                              ),
                            )
                          : SizedBox(),
                      signin
                          ? Container(
                              child: Row(
                                mainAxisAlignment: MainAxisAlignment.start,
                                children: <Widget>[
                                  Checkbox(
                                    activeColor: Colors.orange,
                                    value: true,
                                    onChanged: (value) {},
                                  ),
                                  Text(
                                    "Remeber me and Keep me logged in",
                                    style: TextStyle(
                                      color: Colors.grey,
                                      fontFamily: "Loto",
                                      fontSize: 17,
                                    ),
                                  ),
                                ],
                              ),
                            )
                          : Container(
                              child: Row(
                                mainAxisAlignment: MainAxisAlignment.start,
                                children: <Widget>[
                                  Checkbox(
                                    activeColor: Colors.orange,
                                    value: true,
                                    onChanged: (value) {},
                                  ),
                                  Text(
                                    "By signing up you agree to our Conditions \nPrivacy policy",
                                    style: TextStyle(
                                      color: Colors.grey,
                                      fontFamily: "Loto",
                                      fontSize: 17,
                                    ),
                                  ),
                                ],
                              ),
                            ),
                      SizedBox(
                        height: 10,
                      ),
                      SizedBox(
                        width: double.infinity,
                        height: 50,
                        child: FlatButton(
                          shape: OutlineInputBorder(
                            borderSide: BorderSide.none,
                            borderRadius: BorderRadius.circular(5),
                          ),
                          color: Color(0xff306060),
                          onPressed: () {},
                          child: Text(
                            "SIGN IN",
                            style: TextStyle(
                              color: Colors.white,
                              fontSize: 20,
                            ),
                          ),
                        ),
                      ),
                      Spacer(),
                      Center(
                        child: Text(
                          "- Or you can also -",
                          style: TextStyle(
                            color: Colors.grey,
                            fontSize: 16,
                          ),
                        ),
                      ),
                      Spacer(),
                      SizedBox(
                        width: double.infinity,
                        height: 50,
                        child: RaisedButton(
                          shape: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(5),
                            borderSide: BorderSide(
                              width: 1,
                              color: Colors.grey,
                            ),
                          ),
                          onPressed: () {},
                          color: Colors.white,
                          elevation: 0,
                          child: Row(
                            children: <Widget>[
                              Image.asset(
                                "images/g.png",
                                height: 25,
                                width: 25,
                              ),
                              Spacer(),
                              signin
                                  ? Text(
                                      "SIGN IN WITH GOOGLE",
                                      style: TextStyle(
                                        color: Colors.grey,
                                        fontSize: 17,
                                      ),
                                    )
                                  : Text(
                                      "SIGN UP WITH GOOGLE",
                                      style: TextStyle(
                                        color: Colors.grey,
                                        fontSize: 17,
                                      ),
                                    ),
                              Spacer(),
                            ],
                          ),
                        ),
                      ),
                      Spacer(),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
